"""
Vision analysis — sends a user-uploaded chart screenshot to Groq's
multimodal model and gets back a structured trading read (direction,
confidence, key levels, reasoning) grounded in what's visible in the image.
"""
import base64
import io
import json
import logging
import re
import time

import requests
from PIL import Image

from config import GROQ_API_KEY, GROQ_VISION_MODEL

log = logging.getLogger("mi.vision")

_GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
_MAX_DIMENSION = 1568  # Groq/most vision models cap useful resolution around here
_JPEG_QUALITY = 85

_SYSTEM_PROMPT = """You are an expert price-action / SMC-ICT chart analyst reading a screenshot of a trading platform chart (e.g. Quotex, TradingView, MetaTrader).

Look ONLY at what is visibly present in the image: candle colors and shapes, visible trend direction, higher-highs/higher-lows or lower-highs/lower-lows structure, obvious support/resistance levels, candle wicks vs bodies, and any visible indicators overlaid on the chart (moving averages, RSI panel, etc. — only if actually drawn on the chart).

Respond with STRICT JSON only, no markdown fences, no commentary outside the JSON, matching exactly this schema:
{
  "asset_guess": "string or null — the traded pair/asset name if visible as text on the chart, else null",
  "direction": "BUY" or "SELL" or "NEUTRAL",
  "confidence": integer 0-100,
  "trend": "BULLISH" or "BEARISH" or "RANGING",
  "key_observation": "one short sentence, max 20 words, on the strongest visible pattern",
  "reasons": ["short bullet 1", "short bullet 2", "short bullet 3"] (max 4 items, each under 12 words),
  "risk_note": "one short sentence flagging any visible reason for caution, or null"
}

If the image does not show a readable price chart, set "direction" to "NEUTRAL", "confidence" to 0, and explain in "key_observation" that no valid chart was detected. Never invent price values or indicator readings that are not visibly present."""


def _extract_json(text: str) -> dict | None:
    """Groq sometimes wraps JSON in markdown fences or adds stray text
    despite instructions — strip fences and try progressively looser
    extraction strategies before giving up."""
    text = text.strip()

    # Strip markdown code fences if present
    cleaned = re.sub(r"^```(?:json)?\s*", "", text)
    cleaned = re.sub(r"\s*```$", "", cleaned)

    try:
        return json.loads(cleaned)
    except Exception:
        pass

    # Try finding the first balanced {...} block (handles leading/trailing
    # commentary the model added despite instructions not to).
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end != -1 and end > start:
        candidate = cleaned[start:end + 1]
        try:
            return json.loads(candidate)
        except Exception:
            pass

    return None


def _preprocess_image(image_bytes: bytes) -> bytes:
    """
    Resize and compress the screenshot before sending it over the wire.
    Phone screenshots are often 2-4MB at resolutions far beyond what the
    vision model needs, which slows down upload and processing for no
    accuracy benefit. This keeps analysis fast without losing readability
    of chart details.
    """
    try:
        img = Image.open(io.BytesIO(image_bytes))
        img = img.convert("RGB")

        w, h = img.size
        if max(w, h) > _MAX_DIMENSION:
            ratio = _MAX_DIMENSION / max(w, h)
            img = img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)

        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=_JPEG_QUALITY, optimize=True)
        result = buf.getvalue()
        log.info(f"Preprocessed image: {len(image_bytes)} bytes -> {len(result)} bytes")
        return result
    except Exception as e:
        log.warning(f"Image preprocessing failed, using original: {e}")
        return image_bytes


def analyze_chart_image(image_bytes: bytes, timeframe: str, expiry_minutes: int):
    """
    Send a chart screenshot to the Groq vision model.

    Returns a tuple: (analysis_dict_or_None, error_code_or_None, error_detail_or_None)

    error_code is one of:
      "no_api_key"    — GROQ_API_KEY not configured on the server
      "auth_failed"   — Groq rejected the API key (401/403)
      "rate_limited"  — Groq rate limit hit (429)
      "bad_request"   — Groq rejected the request (400, e.g. image too large/invalid)
      "server_error"  — Groq-side 5xx error
      "network_error" — could not reach Groq at all (timeout/DNS/connection)
      "parse_error"   — got a response but couldn't parse it as valid JSON
      None            — success, analysis_dict is populated
    """
    if not GROQ_API_KEY:
        log.error("GROQ_API_KEY not configured")
        return None, "no_api_key", "GROQ_API_KEY environment variable is empty or not set."

    t0 = time.time()
    processed_bytes = _preprocess_image(image_bytes)
    b64_image = base64.b64encode(processed_bytes).decode("utf-8")
    log.info(f"Image encoded for Groq in {time.time()-t0:.2f}s")

    user_text = (
        f"This chart is set to a {timeframe} timeframe. The trader intends to "
        f"enter a trade with a {expiry_minutes}-minute expiry. Analyze the visible "
        f"price action and structure, and return your JSON assessment."
    )

    payload = {
        "model": GROQ_VISION_MODEL,
        "messages": [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_text},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{b64_image}"},
                    },
                ],
            },
        ],
        "temperature": 0.2,
        "max_tokens": 600,
        "response_format": {"type": "json_object"},
    }

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json",
    }

    result = _send_request(payload, headers)

    # Some models reject response_format for vision+JSON combos with a 400 —
    # if so, retry once without it, relying on the prompt's JSON instructions.
    if result[1] == "bad_request" and "response_format" in payload:
        log.warning("Retrying Groq request without response_format (model may not support it)")
        fallback_payload = dict(payload)
        del fallback_payload["response_format"]
        result = _send_request(fallback_payload, headers)

    analysis, error_code, error_detail = result
    if analysis:
        analysis["timeframe"] = timeframe
        analysis["expiry_minutes"] = expiry_minutes
    return analysis, error_code, error_detail


def _send_request(payload: dict, headers: dict):
    """Send one request to Groq and parse the result. Returns (analysis, error_code, error_detail)."""
    t0 = time.time()
    try:
        r = requests.post(_GROQ_URL, headers=headers, json=payload, timeout=45)
    except requests.exceptions.Timeout:
        log.error(f"Groq request timed out after {time.time()-t0:.1f}s")
        return None, "network_error", "Request to Groq timed out after 45s."
    except requests.exceptions.ConnectionError as e:
        log.error(f"Groq connection failed after {time.time()-t0:.1f}s: {e}")
        return None, "network_error", f"Could not reach api.groq.com: {e}"
    except requests.exceptions.RequestException as e:
        log.error(f"Groq request failed after {time.time()-t0:.1f}s: {e}")
        return None, "network_error", str(e)

    log.info(f"Groq HTTP round-trip: {time.time()-t0:.2f}s (status {r.status_code})")

    if r.status_code == 401 or r.status_code == 403:
        detail = _safe_error_detail(r)
        log.error(f"Groq auth failed ({r.status_code}): {detail}")
        return None, "auth_failed", detail

    if r.status_code == 429:
        detail = _safe_error_detail(r)
        log.error(f"Groq rate limited: {detail}")
        return None, "rate_limited", detail

    if r.status_code == 400:
        detail = _safe_error_detail(r)
        log.error(f"Groq rejected request (400): {detail}")
        return None, "bad_request", detail

    if r.status_code >= 500:
        detail = _safe_error_detail(r)
        log.error(f"Groq server error ({r.status_code}): {detail}")
        return None, "server_error", detail

    if r.status_code != 200:
        detail = _safe_error_detail(r)
        log.error(f"Groq unexpected status {r.status_code}: {detail}")
        return None, "server_error", f"HTTP {r.status_code}: {detail}"

    try:
        result_json = r.json()
        content = result_json["choices"][0]["message"]["content"]
    except (KeyError, IndexError, ValueError) as e:
        log.error(f"Unexpected Groq response shape: {e} — raw: {r.text[:300]}")
        return None, "parse_error", f"Unexpected response shape from Groq: {e}"

    if not content or not content.strip():
        log.error("Groq returned an empty message content")
        return None, "parse_error", "Model returned an empty response."

    parsed = _extract_json(content)
    if not parsed:
        # Log the FULL content server-side (not just a preview) so it's fully
        # visible in GitHub Actions logs / diagnostics for debugging.
        log.error(f"Could not parse vision response as JSON. Raw content:\n{content}")
        preview = content.strip()[:150].replace("\n", " ")
        return None, "parse_error", f"Model output: \"{preview}...\"" if len(content.strip()) > 150 else f"Model output: \"{preview}\""

    return _normalize_analysis(parsed), None, None


def _normalize_analysis(parsed: dict) -> dict:
    direction = str(parsed.get("direction", "NEUTRAL")).upper()
    if direction not in ("BUY", "SELL", "NEUTRAL"):
        direction = "NEUTRAL"

    confidence = parsed.get("confidence", 0)
    try:
        confidence = max(0, min(100, int(confidence)))
    except (ValueError, TypeError):
        confidence = 0

    reasons = parsed.get("reasons", [])
    if not isinstance(reasons, list):
        reasons = []
    reasons = [str(r) for r in reasons][:4]

    analysis = {
        "asset_guess": parsed.get("asset_guess"),
        "direction": direction,
        "confidence": confidence,
        "trend": parsed.get("trend", "RANGING"),
        "key_observation": parsed.get("key_observation", ""),
        "reasons": reasons,
        "risk_note": parsed.get("risk_note"),
    }
    return analysis


def _safe_error_detail(response) -> str:
    """Best-effort extraction of a human-readable error message from a Groq error response."""
    try:
        data = response.json()
        return data.get("error", {}).get("message", response.text[:300])
    except Exception:
        return response.text[:300] if response.text else f"HTTP {response.status_code}"
